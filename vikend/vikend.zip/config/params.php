<?php

return [
    'adminEmail' => 'milos_dodic@live.com',
    'adminPswd' => 'lozinka123'
];
