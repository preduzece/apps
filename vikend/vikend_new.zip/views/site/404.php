<?php
use yii\helpers\Url;
use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = '404';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">

    <div class="blog-post-area">
        <h2 class="title text-center">Gde za vikend - Greska 404</h2>
        <div class="single-blog-post">
            <a href="#">
                <img src="<?= Url::base() ?>/img/404/404.png" alt="">
            </a>


        </div>
    </div><!--/blog-post-area-->

</div>
