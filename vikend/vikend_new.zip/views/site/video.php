<div class="single-blog-post">
	<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <!-- 16:9 aspect ratio -->
        <div class="embed-responsive embed-responsive-16by9" style="margin-bottom: 30px">
	       <iframe class="embed-responsive-item" src="//www.youtube.com/embed/<?= $model->link ?>"></iframe>
	    </div>
	</div>
</div>
