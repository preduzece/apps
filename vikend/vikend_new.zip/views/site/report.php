<?php
use yii\helpers\Url;
use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = 'Obavestenje';
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="blog-post-area">
        <h2 class="title text-center">Gde za vikend - Obavestenje</h2>

</div>

<h2>Stranica je u izradi, hvala na strpljenju!</h2>
<p class="text-right"><i>Vas GdeZaVikend</i></p>