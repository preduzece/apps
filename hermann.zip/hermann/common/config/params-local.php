<?php
Yii::setAlias('@anyname', realpath(dirname(__FILE__).'/../../'));

return [
];
