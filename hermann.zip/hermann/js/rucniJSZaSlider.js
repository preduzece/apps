$('#main-slider').lush({
                autostart:  true
                , manual: true
                , responsive: true
                , baseWidth:  1280
                , baseHeight: 720
                , deadtime: 5000
                , flexslider : {
                  animation:    'slide'
                  , easing:       'easeInOutExpo'
                  , useCSS:       true
                  , pauseOnHover: true
                  , responsive: true
              }
            });