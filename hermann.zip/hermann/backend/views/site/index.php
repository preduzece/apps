<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Hermann - Admin panel</h1>
    </div>

    <div class="row" >
        <div class="col-sm-6 col-sm-offset-4">
            <img src="uploads/user_admin.png" alt="" style="height:300px">
        </div>
    </div>

    


</div>
